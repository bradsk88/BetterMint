# BetterMint
Chrome Extension for adding UI improvements to Mint.com

This extension is currently in early development.

Planned features are catalogued under "issues"
